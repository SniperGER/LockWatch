#import <UIKit/UIKit.h>

@interface LWKClockHand : UIImageView

+ (id)hour;
+ (id)minute;
+ (id)second;

@end

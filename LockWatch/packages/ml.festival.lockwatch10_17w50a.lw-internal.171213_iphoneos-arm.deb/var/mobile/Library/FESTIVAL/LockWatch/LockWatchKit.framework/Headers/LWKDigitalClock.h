//
//  LWKDigitalClock.h
//  LockWatch
//
//  Created by Janik Schmidt on 13.12.17.
//
//

#import <LockWatchKit/LockWatchKit.h>

@interface LWKDigitalClock : LWKClockBase {
	UILabel* clockLabel;
}

@end

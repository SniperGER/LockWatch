#import <UIKit/UIKit.h>

@interface LWKClockBase : NSObject {
	NSTimer* clockUpdateTimer;
}

@property (nonatomic, strong) UIView* backgroundView;
@property (nonatomic, strong) UIView* contentView;
@property (nonatomic, strong) UIView* clockView;

- (void)didStartUpdatingTime;
- (void)didStopUpdatingTime;
- (void)updateForHour:(CGFloat)hour minute:(CGFloat)minute second:(CGFloat)second millisecond:(CGFloat)msecond animated:(BOOL)animated;
- (void)prepareForInit;

@end

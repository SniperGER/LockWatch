#import <UIKit/UIKit.h>
#import <objc/runtime.h>

@interface LWKPageView : UIView {
	UILabel* titleLabel;
	UIView* backgroundView;
}

- (void)setBackgroundAlpha:(CGFloat)alpha;

@end

#import <LockWatchKit/LockWatchKit.h>

@interface LWKDigitalClock : LWKClockBase {
	UILabel* clockLabel;
}

@end

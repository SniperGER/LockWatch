#import <Foundation/Foundation.h>
#import <sqlite3.h>

@interface LWKActivityDataProvider : NSObject

+ (NSDictionary*)activityData;

@end
